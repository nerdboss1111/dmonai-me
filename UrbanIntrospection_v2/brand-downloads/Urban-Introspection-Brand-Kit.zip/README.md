# Urban Introspection by Deon Monai

Good art. Strange finds. Second lives.

## What is included

- Ten-page visual brand guide.
- Original Rooftop Cut display font: TTF for installation and WOFF for web.
- Vector SVG and transparent PNG logos: primary, ink, reversed and UI monogram.
- Editable SVG social artwork and ready PNG exports: square, story, banner and reminder.
- Four-page print pack: 6 x 4 inch thank-you card (front/back) and 2 x 3.5 inch hang tag (front/back).
- Palette JSON and source-art provenance manifest.

## Font

Install the TTF for desktop design software. The uppercase display alphabet includes 26 letters, digits and basic punctuation. Lowercase input maps to uppercase. It is not a full multilingual font family. Use Arial/Helvetica for body text and Courier for utility labels.

## Print

Card and tag PDF pages include 0.125 inch bleed on all sides and embedded TrimBox/BleedBox values. Print at actual size; ask the printer to align the front and back to the trim boxes. No punch hole is printed on tags: position it after reviewing the physical proof. Digital RGB art should be color-proofed on the intended stock before a production run. Templates contain no unconfirmed address, URL or contact information.

## Artwork

The original art belongs to Deon Monai. It was not retouched or regenerated. Web copies are resized/compressed for delivery. Original file hashes and Drive IDs are recorded in artwork-manifest.json. Study numbers are navigation labels, not newly assigned official artwork titles. All shop voice and brand copy is a proposed creative draft.

## Shop status

The website is a working interactive collection preview. Favorites and preview-bag selections persist in each visitor's browser. Prices, dimensions, stock, payment, shipping and returns must be configured with real inventory before taking orders. The category images for thrift, upcycles and odd finds are original artwork used as editorial visuals; they are not product inventory photographs.
